Dialog by XDSoft.net
======
[Documentation&Demo][doc]

Simple dialog system

Video Player with custom buttons

![ScreenShot](https://raw.github.com/xdan/dialog/master/screen/1.png)

Confirm

![ScreenShot](https://raw.github.com/xdan/dialog/master/screen/2.png)

Wait dialog

![ScreenShot](https://raw.github.com/xdan/dialog/master/screen/3.png)

Youtube player

![ScreenShot](https://raw.github.com/xdan/dialog/master/screen/4.png)

[doc]: http://xdsoft.net/jqplugins/dialog/